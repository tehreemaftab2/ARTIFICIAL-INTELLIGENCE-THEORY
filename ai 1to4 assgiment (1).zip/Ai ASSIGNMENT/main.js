// auto submit on change for selects and dates to improve UX
document.addEventListener('DOMContentLoaded', function(){
  const form = document.getElementById('filter-form');
  if(!form) return;

  // submit when any select or date changes (but keep manual Apply button too)
  const inputs = form.querySelectorAll('select, input[type="date"]');
  inputs.forEach(inp => {
    inp.addEventListener('change', () => {
      // small debounce
      if(window._submitTimeout) clearTimeout(window._submitTimeout);
      window._submitTimeout = setTimeout(() => form.submit(), 600);
    });
  });
});
