from flask import Flask, render_template, request, send_file
import pandas as pd
import matplotlib
matplotlib.use('Agg')  
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import io
import base64

app = Flask(__name__)

def load_data():
    df = pd.read_csv(".supermarket_flask/data.csv")
    df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_', regex=False)
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
    df['total'] = pd.to_numeric(df['total'], errors='coerce')
    return df

df = load_data()

def fig_to_base64(fig):
    img = io.BytesIO()
    fig.savefig(img, format='png', bbox_inches='tight')
    img.seek(0)
    return base64.b64encode(img.getvalue()).decode()

@app.route('/', methods=['GET', 'POST'])
def index():
    filtered = df.copy()
    
    city_filter = request.form.get('city', '').split(',')
    product_filter = request.form.get('product_line', '').split(',')
    gender_filter = request.form.get('gender', '').split(',')
    search_city = request.form.get('search_city', '').title()
    search_product = request.form.get('search_product', '').title()

    if city_filter and city_filter != ['']:
        city_filter = [c.strip() for c in city_filter]
        filtered = filtered[filtered['city'].isin(city_filter)]
    if product_filter and product_filter != ['']:
        product_filter = [p.strip() for p in product_filter]
        filtered = filtered[filtered['product_line'].isin(product_filter)]
    if gender_filter and gender_filter != ['']:
        gender_filter = [g.strip() for g in gender_filter]
        filtered = filtered[filtered['gender'].isin(gender_filter)]

    search_info = ""
    if search_city:
        if search_city in filtered['city'].str.title().unique():
            total = filtered[filtered['city'].str.title() == search_city]['total'].sum()
            search_info += f"Total sales in {search_city}: ${total:,.2f} | "
        else:
            search_info += f"{search_city} not found | "

    if search_product:
        if search_product in filtered['product_line'].str.title().unique():
            total = filtered[filtered['product_line'].str.title() == search_product]['total'].sum()
            search_info += f"Total sales for {search_product}: ${total:,.2f}"
        else:
            search_info += f"{search_product} not found"


    total_sales = filtered['total'].sum()
    avg_rating = filtered['rating'].mean()
    transactions = len(filtered)

    fig1, ax1 = plt.subplots()
    grouped_product = filtered.groupby('product_line')['total'].sum().sort_values()
    grouped_product.plot(kind='barh', ax=ax1, color='#1f77b4', edgecolor='black')
    ax1.set_xlabel("Total Sales")
    plot_product = fig_to_base64(fig1)
    plt.close(fig1)


    fig2, ax2 = plt.subplots()
    grouped_city = filtered.groupby('city')['total'].sum()
    ax2.pie(grouped_city, labels=grouped_city.index, autopct='%1.1f%%', startangle=140)
    ax2.axis('equal')
    plot_city = fig_to_base64(fig2)
    plt.close(fig2)

    fig3, ax3 = plt.subplots()
    gender_data = filtered.groupby('gender')['total'].sum()
    sns.barplot(x=gender_data.index, y=gender_data.values, ax=ax3, palette="Set2")
    plot_gender = fig_to_base64(fig3)
    plt.close(fig3)

    fig4, ax4 = plt.subplots()
    payment_data = filtered['payment'].value_counts()
    ax4.pie(payment_data, labels=payment_data.index, autopct='%1.1f%%', startangle=90)
    ax4.axis('equal')
    plot_payment = fig_to_base64(fig4)
    plt.close(fig4)

    fig5, ax5 = plt.subplots(figsize=(8,6))
    corr = filtered.select_dtypes(include=np.number).corr()
    sns.heatmap(corr, annot=True, cmap='YlGnBu', linewidths=0.5, ax=ax5)
    plot_corr = fig_to_base64(fig5)
    plt.close(fig5)

    fig6, ax6 = plt.subplots()
    if 'date' in filtered.columns:
        monthly = filtered.resample('ME', on='date')['total'].sum()
        monthly.plot(marker='o', linestyle='--', linewidth=2, color='#FF5733', ax=ax6)
        ax6.set_title("Monthly Sales Trend")
        ax6.set_xlabel("Month")
        ax6.set_ylabel("Total Sales")
        fig6.autofmt_xdate()
    plot_monthly = fig_to_base64(fig6)
    plt.close(fig6)

    
    top_city = filtered.groupby('city')['total'].sum().idxmax() if not filtered.empty else "N/A"
    top_payment = filtered['payment'].value_counts().idxmax() if not filtered.empty else "N/A"
    top_product = filtered.groupby('product_line')['total'].sum().idxmax() if not filtered.empty else "N/A"
    last_30_total = filtered.sort_values('date', ascending=False).head(30)['total'].sum() if not filtered.empty else 0


    csv_data = filtered.to_csv(index=False)

    return render_template(
        "index.html",
        total_sales=f"${total_sales:,.2f}",
        avg_rating=f"{avg_rating:.2f}",
        transactions=transactions,
        plot_product=plot_product,
        plot_city=plot_city,
        plot_gender=plot_gender,
        plot_payment=plot_payment,
        plot_corr=plot_corr,
        plot_monthly=plot_monthly,
        top_city=top_city,
        top_payment=top_payment,
        top_product=top_product,
        last_30_total=f"${last_30_total:,.2f}",
        data_html=filtered.to_html(classes='table table-striped', index=False),
        search_info=search_info,
        csv_data=csv_data
    )

@app.route('/download')
def download_csv():
    csv = df.to_csv(index=False)
    return send_file(io.BytesIO(csv.encode()), mimetype='text/csv', as_attachment=True, attachment_filename='filtered_data.csv')

if __name__ == '__main__':
    app.run(debug=True)
